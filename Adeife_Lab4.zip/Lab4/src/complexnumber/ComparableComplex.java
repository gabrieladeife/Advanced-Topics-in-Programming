package complexnumber;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author TJ
 */
public class ComparableComplex extends Complex implements Comparable<ComparableComplex>{
    
    ComparableComplex(double real, double img){
        super(real, img);
    }
    
    @Override 
    public String toString(){
        String realNum = String.format("%.2f", getReal());
        String realImg = String.format("%+.2f", getImg());
        return realNum + " " + realImg +"i";
    }
    
    @Override
    public double findLength(){
        return Math.sqrt(Math.pow(getReal(),2) + Math.pow(getImg(), 2));
    }
    
    @Override 
     public int compareTo(ComparableComplex comp){
        if (findLength() == comp.findLength()) return 0;
        else if (findLength() > comp.findLength()) return 1;
        else return -1;
    }
}
