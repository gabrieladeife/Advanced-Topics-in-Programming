package complexnumber;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author TJ
 */
abstract class Complex implements ArithmeticOpe{
    
    private double real;
    private double img;
    
    protected Complex(double real, double img){
        this.real = real;
        this.img = img;
    }
    
    public void setReal(double real){
        this.real = real;
    }
    
    public void setImg(double img){
        this.img = img;
    }
    
    public double getReal(){
        return real;
    }
    
    public double getImg(){
        return img;
    }
    
    @Override
    public Complex addition(Complex comp){
        comp.setReal(this.real + comp.getReal());
        comp.setImg(this.img + comp.getImg());
        return comp;
    }
    
    @Override
    public Complex subtraction(Complex comp){
      comp.setReal(comp.getReal() - this.real);
      comp.setImg(comp.getImg() - this.img);
      return comp;
    }
            
    public abstract double findLength();
}
