package complexnumber;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author TJ
 */
public class ComplexTest {
    public static void main(String[] args){
        ComparableComplex c1 = new ComparableComplex(4.1, -1.2);
        ComparableComplex c2 = new ComparableComplex(-2.4, 3.7);
        ComparableComplex c3 = (ComparableComplex)c1.addition(c2);
        System.out.println(c3.toString());
        c1.subtraction(c2);
        ComparableComplex c4 = (ComparableComplex)c2.subtraction(c1);
        System.out.println(c4.toString());
        
    }
}
