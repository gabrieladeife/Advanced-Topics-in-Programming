/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Lab8;

/**
 *
 * @author TJ
 */
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.sql.*;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.layout.Region;

public class FindGrade extends Application {
  // Statement for executing queries
  private Statement stmt;
  private Label lblStatus = new Label();
  private TextArea displayInf = new TextArea();
  private TextField tfTableName = new TextField();
  
  @Override // Override the start method in the Application class
  public void start(Stage primaryStage) {
    // Initialize database connection and create a Statement object
    initializeDB();
    Region a  = new Region();
    a.setPrefWidth(100);
    Button btShowGrade = new Button("Show Contents");
    ScrollPane sP = new ScrollPane(displayInf);
    HBox hBox = new HBox(5);
    hBox.getChildren().addAll(a, new Label("Table Name"), tfTableName,  (btShowGrade));
    VBox vBox = new VBox(0);
    vBox.getChildren().addAll(hBox, sP, lblStatus);
    tfTableName.setPrefColumnCount(6);
    btShowGrade.setOnAction(e -> showGrade());
    
    // Create a scene and place it in the stage
    Scene scene = new Scene(vBox, 500, 150);
    primaryStage.setTitle("FindGrade"); // Set the stage title
    primaryStage.setScene(scene); // Place the scene in the stage
    primaryStage.show(); // Display the stage   
  }
  private void initializeDB() {
    try {
      // Load the JDBC driver
      Class.forName("com.mysql.cj.jdbc.Driver");
//      Class.forName("oracle.jdbc.driver.OracleDriver");
      System.out.println("Driver loaded");
      // Establish a connection
      Connection connection = DriverManager.getConnection
        ("jdbc:mysql://localhost/javabook", "scott", "tiger");
//    ("jdbc:oracle:thin:@liang.armstrong.edu:1521:orcl",
//     "scott", "tiger");
      System.out.println("Database connected");
      // Create a statement
      stmt = connection.createStatement();
    }
    catch (Exception ex) {
      ex.printStackTrace();
    }
  }
  private void showGrade() {
    String tableName = tfTableName.getText();
    String queryString = " ";
    int numCourseFound = 0;
     if(tableName.equalsIgnoreCase("Enrollment")){
         displayInf.appendText("ssn\t courseId\t dateRegistered\t grade\n");
         queryString = "select enrollment.ssn, enrollment.courseId, enrollment.dateRegistered, enrollment.grade from enrollment";
     }
     if(tableName.equalsIgnoreCase("course")) {
         displayInf.appendText("courseId\t subjectId\t courseNumber title numOfCredits\n");
         queryString =  "select course.courseId, course.subjectId, course.courseNumber, course.title, course.numOfCredits from course";
     }
     if(tableName.equalsIgnoreCase("college")) {
         displayInf.appendText("collegeId\t name\t since\t \tdeanId\n");
         queryString = "select college.collegeId, college.name, college.since, college.deanid from college";
     }
     if(tableName.equalsIgnoreCase("department")){
         displayInf.appendText("deptId\t name\t chairId\t collegeId\n");
         queryString = "select department.deptid, department.name, department.chairid, department.collegeid from department";
     }
     if(tableName.equalsIgnoreCase("faculty")){
         displayInf.appendText("ssn\t firstName\t mi\t lastName\t phone\t email\t office\t startTime\t rank1\t salary\t deptId\n");
         queryString = "select faculty.ssn, faculty.firstname, faculty.mi, faculty.lastname, faculty.phone, faculty.email, faculty.office, faculty.startTime, faculty.rank1, faculty.salary, faculty.deptId from faculty";
     }
     if(tableName.equalsIgnoreCase("student")){
         displayInf.appendText("ssn\t firstName\t mi\t lastName\t phone\t birthDate\t street\t zipCode\t deptId\n");
         queryString = "select ssn, firstname, mi, lastname, phone, birthdate, street, zipcode, deptid from student";
     }
     if(tableName.equalsIgnoreCase("subject")){
         displayInf.appendText("subjectId\t name\t startTime\t deptId\n");
         queryString = "select subjectId, name, starttime, deptid from subject";
     }
     if(tableName.equalsIgnoreCase("taughtby")){
         displayInf.appendText("courseId\t ssn\n");
         queryString = "select courseId, ssn from taughtby";
     }
    try {
        ResultSet rset= stmt.executeQuery(queryString);
         if (rset.next()){
             do{
                 if(tableName.equalsIgnoreCase("taughtby")){
                 String courseId = rset.getString(1);
                 String ssn = rset.getString(2);
                 String label = courseId + " \t" + ssn + " \n";
                 displayInf.appendText(label);
                 }
                 if(tableName.equalsIgnoreCase("subject")){
                 String subjectId = rset.getString(1);
                 String name = rset.getString(2);
                 String starttime = rset.getString(3);
                 String deptid = rset.getString(4);
                 String label = subjectId + " \t" + name + " \t" + starttime + " \t" + deptid + " \n";
                 displayInf.appendText(label);
                 }
                 if(tableName.equalsIgnoreCase("student")){
                 String ssn = rset.getString(1);
                 String firstName = rset.getString(2);
                 String mi = rset.getString(3);
                 String lastName = rset.getString(4);
                 String phone = rset.getString(5);
                 String birthdate = rset.getString(6);
                 String street = rset.getString(7);
                 String zipcode = rset.getString(8);
                 String deptid = rset.getString(9);
                 String label = ssn + " \t" + firstName + " \t" + mi + " \t" + lastName + " \t" + phone + " \t"
                         + birthdate + " \t" + street + " \t" + zipcode + " \t" + deptid +"\n";
                 displayInf.appendText(label);
                 }
                 if(tableName.equalsIgnoreCase("faculty")){
                 String ssn = rset.getString(1);
                 String firstName = rset.getString(2);
                 String mi = rset.getString(3);
                 String lastName = rset.getString(4);
                 String phone = rset.getString(5);
                 String email = rset.getString(6);
                 String office = rset.getString(7);
                 String startTime = rset.getString(8);
                 String rank1 = rset.getString(9);
                 String deptId = rset.getString(10);
                 String label = ssn + " \t" + firstName + " \t" + mi + " \t" + lastName + " \t" + phone + " \t" 
                         + email + " \t" + office + " \t" + startTime + " \t" + rank1 + " \t" + deptId + " \n";
                 displayInf.appendText(label);
                 }
                 if(tableName.equalsIgnoreCase("department")){
                 String deptId = rset.getString(1);
                 String name = rset.getString(2);
                 String chairId = rset.getString(3);
                 String collegeId = rset.getString(4);
                 String label = deptId + "\t " + name + "\t " + chairId + "\t " + collegeId + "\n";
                 displayInf.appendText(label);
                 }
                 if(tableName.equalsIgnoreCase("college")){
                 String collegeId = rset.getString(1);
                 String name = rset.getString(2);
                 String since = rset.getString(3);
                 String deanId = rset.getString(4);
                 String label = collegeId + "\t" + name + "\t" + since + "\t" + deanId + "\n";
                 displayInf.appendText(label);
                 }
                 if(tableName.equalsIgnoreCase("Enrollment")){
                 String tableSsn = rset.getString(1);
                 String tableCourseId = rset.getString(2);
                 String dateRegistered = rset.getString(3);
                 String grade = rset.getString(4);
                 String label = tableSsn +  "\t"  + tableCourseId + "\t" + dateRegistered + "\t" + grade + " \t\n";
                 displayInf.appendText(label);
                 }
                 if(tableName.equalsIgnoreCase("course")){
                 String courseId = rset.getString(1);
                 String subjectId = rset.getString(2);
                 String courseNumber = rset.getString(3);
                 String title = rset.getString(4);
                 String numOfCredits = rset.getString(5);
                 String label = courseId + " \t" + subjectId + " \t" + courseNumber + " \t" + title + " \t" + numOfCredits +"\n";
                 displayInf.appendText(label);
                 }
                 
             }while(rset.next());
         }
      
      /*ResultSet rset = stmt.executeQuery(queryString);
      if (rset.next()) {
        do{
        numCourseFound++;
        String lastName = rset.getString(3);
        String mi = rset.getString(2);
        String firstName = rset.getString(1);
        String title = rset.getString(4);
        String grade = rset.getString(5);
        String label = firstName + " "  + mi + " " + lastName + "'s grade on course " +  title + " is " + grade + "\n";
        // Display result in a label*/
        //displayInf.appendText(label);
       // } while(rset.next());
        // lblStatus.setText(numCourseFound + " courses found");
      //} else {
        //lblStatus.setText("no courses found for this SSN");
      //}
    }
    catch (SQLException ex) {
      ex.printStackTrace();
    }
  }
  public static void main(String[] args) {
    launch(args);
  }
}