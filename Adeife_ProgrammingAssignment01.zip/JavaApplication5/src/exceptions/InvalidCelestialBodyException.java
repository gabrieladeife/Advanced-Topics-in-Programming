/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package exceptions;

/**
 *
 * @author TJ
 */
public class InvalidCelestialBodyException extends Exception{
    
    public InvalidCelestialBodyException(String message){
        super(message);
    }
}
