/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package solarsystem;
import java.util.*;

import exceptions.DuplicateCelestialBodyException;
import exceptions.InvalidCelestialBodyException;

/**
 *
 * @author TJ
 */
public class CelestialBody {

    /**
     * @param args the command line arguments
     */
    private String name;
    private String type;
    
    private ArrayList<CelestialBody> Children = new ArrayList<>();
    
    public CelestialBody(String name, String type){
        this.name = name;
        this.type = type;
    }
    
    public String getName(){
        return name;
    }
    
    public String getType(){
        return type;
    }
    
    public void add(CelestialBody child) throws DuplicateCelestialBodyException{
        
     for(CelestialBody childs : getChildren()){
         if(childs.getName().equalsIgnoreCase(child.getName()))
             throw new DuplicateCelestialBodyException("The " + child.getType() + " " + child.getName() + " already exists in the collection");
             
     }
     getChildren().add(child);
     System.out.println("The " + child.getType() + " " + child.getName() + " was added successfully to " + getName());
    }
    
    public ArrayList<CelestialBody> getChildren(){
    return(Children);
    }
    
}
