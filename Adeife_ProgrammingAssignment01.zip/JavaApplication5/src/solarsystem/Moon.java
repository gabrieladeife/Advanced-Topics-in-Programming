/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package solarsystem;

import exceptions.InvalidCelestialBodyException;
/**
 *
 * @author TJ
 */
public class Moon extends CelestialBody implements IOrbit {
    
    private CelestialBody orbits;
    
    public Moon(String name, CelestialBody orbits) throws InvalidCelestialBodyException{
        super(name, "moon");
        if(orbits instanceof Planet)
            this.orbits = orbits;
        else 
            throw new InvalidCelestialBodyException("A moon must orbit a planet.");
    }
    
    @Override
    public void getOrbit(){
     System.out.println(getName()+ " is orbiting the Planet " + orbits.getName());   
    }
}
