/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package solarsystem;

import exceptions.DuplicateCelestialBodyException;
import exceptions.InvalidCelestialBodyException;
/**
 *
 * @author TJ
 */
public class SolarSystem {
    
    public static void main(String[] args) throws InvalidCelestialBodyException {
        try {
            Star sun = new Star("Sun", 5778000);
            Planet mercury = new Planet("Mercury", sun);
            Planet venus = new Planet("Venus", sun);
            Planet earth = new Planet("Earth", sun);
            Planet mars = new Planet ("Mars", sun);
            Planet jupiter = new Planet("Jupiter", sun);
            Planet saturn = new Planet("Saturn", sun);
            Planet uranus = new Planet("Uranus", sun);
            Planet neptune = new Planet("Neptune", sun);
            
            sun.add(mercury);
            sun.add(venus);
            sun.add(earth);
            sun.add(jupiter);
            sun.add(saturn);
            sun.add(uranus);
            sun.add(neptune);
            
            Moon moon = new Moon("The Moon", earth);
            earth.add(moon);
            
            Moon phobos = new Moon("Phobos", mars);
            Moon deimos = new Moon("Deimos", mars);
            
            mars.add(phobos);
            mars.add(deimos);
            mars.add(deimos);
        }
        catch(DuplicateCelestialBodyException ex) {
            System.out.println(ex);
            
        }
    }
    
}
