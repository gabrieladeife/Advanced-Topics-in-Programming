/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package solarsystem;

/**
 *
 * @author TJ
 */
public class Star extends CelestialBody {
    
    private int surfaceTemp;
    
    Star(String name, int surfaceTemp){
        super(name, "Star");
        this.surfaceTemp = surfaceTemp;
    }
    
    public int getSurfaceTemp(){
        return surfaceTemp;
    }
    
}
