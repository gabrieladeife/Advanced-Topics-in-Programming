/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package solarsystem;

import exceptions.InvalidCelestialBodyException;
/**
 *
 * @author TJ
 */
public class Planet extends CelestialBody implements IOrbit {
    private CelestialBody orbits;
    
    public Planet(String name, CelestialBody orbits) throws InvalidCelestialBodyException {
        super(name, "Planet");
       if(orbits instanceof Star)
           this.orbits = orbits;
       else 
           throw new InvalidCelestialBodyException("A planet must orbit a star.");
    }
    
    @Override
    public void getOrbit(){
        System.out.println(getName() + " is orbiting the Star " + orbits.getName());
    }
    
}
